//CSU Fresno
//CSCI 178
//Game Development
//Spring 2023


//Team Name:
	Codebreakers

//Game Name:
	Pixel Hoppers

//Team Roles/Contributions:

	Ricardo Cabrera
		Role: Team Leader, Programmer, Sound Designer, Sprite Maker

		Project Contribtions:
			-Obtained all of the game sprites
				main character sprite
				enemies sprites
				background images
				button sprites
				scenery sprites
				font sprites
			-Obtained all of the game sound files
				player death
				enemy death
				player attack
				button click
				levl BGMs
			-Came up with the initial game idea

		Source Code Contributions
			-Created the Following Classes:
				button
				checkCollosion
				collisionManager
				enms
				Fonts
				GLScene
				Inputs
				levelManager
				parallax
				sceneManager
				scenery
				sounds
				textureLoader

			-Worked on the Following Classes:
				button
				checkCollosion
				collisionManager
				enms
				Fonts
				GLScene
				Inputs
				levelManager
				parallax
				sceneManager
				scenery
				sounds
				textureLoader
				player
				projectile
				commons
			


	Tien Tran
		Role: Programmer, Game Tester

		Project Contributions:
			-Helped to debug some of the game's code to help improve the overall 
				gameplay experience.
			-Contributed ideas for improving the game mechanics to make the 
				gameplay more engaging.

		Source Code Contributions:
			-Created the following Classes:
				player
				projectile
				commons
				GLLight
				Model
			-Worked on the Following Classes:
				GLScene
				player
				Inputs
				projectile
				commons
				GLLight
				Model

		Personal Notes:
			-One of the biggest challenges I faced was ensuring that the user interface was intuitive 
				and easy to navigate for players as well as the player movements can be more interactive.
			-Overall, working on this project was a great learning experience for me, as 
				I gained valuable skills in design, coding, and project management. 


	Jonah Lozano
		Role: Former Team Leader, Currently just a team member

		Project Contributions:
			-Created our first project plan document which assigned parts of the game to
				each team member.
			-After our fourth member dropped the class, he created the second project plan document
				which reassigned parts of the game to the reamaining group members.
				This document would be used to by Ricardo and Tien to work on the game after
					Jonah was absent from the class.
			-Created the GitHub repository for our project.
		
		Source Code Contributions:
			-Jonah created a level loader and multi-key functionality class for his
				Midterm, however the Codebreakers team was unable to obtain these source code files.
			-Therefore, Ricardo and Tien created a game without these source code files.
			-At this point in time Jonah has no source code contributions that are a part of the current game version.
			



